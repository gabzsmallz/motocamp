// ============================================================
// KenyaMotocamp — Nav + SiteCard (depend on store)
// ============================================================
const { useState: useStateS, useMemo: useMemoS } = React;

function Nav() {
  const { route, go, stats, signedIn, setSignedIn, isAdmin } = window.useApp();
  const links = [
    { s: "explore", icon: "map", label: "Map" },
    { s: "browse", icon: "list", label: "Campsites" },
    { s: "trips", icon: "bookmark", label: `My Trips${stats.planned ? ` · ${stats.planned}` : ""}` },
    { s: "suggest", icon: "plus", label: "Suggest" },
  ];
  const cur = route.screen;
  return (
    <nav className="nav">
      <div className="nav__inner">
        <a className="brand" href="#/home" onClick={(e) => { e.preventDefault(); go("home"); }}>
          <span className="brand__mark"><window.Icon name="tent" size={17} /></span>
          <span className="brand__txt">
            <div className="brand__name">Motocamp</div>
            <div className="brand__sub">Kenya Field Guide</div>
          </span>
        </a>
        <div className="nav__links">
          {links.map((l) => (
            <a key={l.s} href={`#/${l.s}`} onClick={(e) => { e.preventDefault(); go(l.s); }}
              className={window.cx("nav__link", (cur === l.s || (l.s === "explore" && cur === "site")) && "is-active")}>
              <window.Icon name={l.icon} size={16} />
              <span className="lbl">{l.label}</span>
            </a>
          ))}
          {isAdmin && (
            <a href="#/admin" onClick={(e) => { e.preventDefault(); go("admin"); }}
              className={window.cx("nav__link", "is-admin", cur === "admin" && "is-active")}>
              <window.Icon name="shield" size={16} />
              <span className="lbl">Admin</span>
            </a>
          )}
        </div>
        <div className="nav__spacer" />
        <span className="nav__stat"><b>{stats.visited}</b> visited · <b>{stats.planned}</b> planned</span>
        <div className="nav__user">
          {signedIn ? (
            <>
              <window.Avatar name="Rider You" size={30} />
              <button className="btn-icn" title="Sign out" onClick={() => setSignedIn(false)} style={{ width: 32, height: 32, background: "transparent", border: "1px solid rgba(255,255,255,.15)", color: "var(--paper-on-ink)" }}>
                <window.Icon name="logOut" size={15} />
              </button>
            </>
          ) : (
            <button className="btn btn--signal btn--sm" onClick={() => setSignedIn(true)}>Sign in</button>
          )}
        </div>
      </div>
    </nav>
  );
}

// ---- SiteCard -------------------------------------------------------
function SiteCard({ site, n, variant = "grid" }) {
  const { go, getData, toggleVisited, togglePlanned } = window.useApp();
  const data = getData(site.id);
  const access = window.ACCESS_LABELS[site.access];
  const [shared, setShared] = useStateS(false);

  const statusTone = data.visited ? "terrain" : data.planned ? "amber" : "signal";

  function share(e) {
    e.stopPropagation();
    navigator.clipboard?.writeText(`${location.origin}/#/site/${site.id}`).catch(() => {});
    setShared(true); setTimeout(() => setShared(false), 1600);
  }

  return (
    <article className={window.cx("sitecard", `sitecard--${variant}`,
      data.visited && "is-visited", data.planned && "is-planned")}
      onClick={() => go("site", site.id)}>
      <div className="sitecard__media">
        <window.SiteImg src={site.photos?.[0]} alt={site.name} className="sitecard__img">
          <div className="sitecard__waypoint"><window.WaypointPin n={n ?? site.id} tone={statusTone} size={28} /></div>
          {site.photos?.length > 1 && (
            <span className="sitecard__photos"><window.Icon name="camera" size={11} /> {site.photos.length}</span>
          )}
          {(data.visited || data.planned) && (
            <window.Stamp tone={data.visited ? "terrain" : "ink"} className="sitecard__status">
              {data.visited ? "✓ Logged" : "Planned"}
            </window.Stamp>
          )}
          <div className="sitecard__access"><window.AccessChip access={site.access} /></div>
        </window.SiteImg>
      </div>

      <div className="sitecard__body">
        <div className="sitecard__head">
          <h3 className="sitecard__name">{site.name}</h3>
          <div className="sitecard__score">
            <window.Icon name="star" size={12} strokeWidth={0} style={{ fill: "var(--signal)" }} />
            <b>{window.round1(site.community.overall).toFixed(1)}</b>
            <span>({site.community.count})</span>
          </div>
        </div>
        <div className="sitecard__loc">
          <window.Icon name="pin" size={12} />
          <span>{site.region}, {site.county}</span>
        </div>
        {variant !== "row" && <p className="sitecard__desc">{site.description}</p>}

        <div className="sitecard__meta">
          <span className="coord">{site.lat.toFixed(3)}, {site.lng.toFixed(3)}</span>
          <span className="sitecard__dot">·</span>
          <span className="coord">{site.distanceFromNairobi} km from Nairobi</span>
        </div>

        <div className="sitecard__foot">
          <window.Facilities items={site.facilities.slice(0, variant === "row" ? 3 : 6)} />
          <div className="sitecard__actions" onClick={(e) => e.stopPropagation()}>
            <button className={window.cx("btn-icn", "btn-icn--sm", shared && "is-on-terrain")} title="Share" onClick={share}>
              <window.Icon name={shared ? "check" : "share"} size={14} />
            </button>
            <button className={window.cx("btn-icn", "btn-icn--sm", data.planned && "is-on-amber")} title="Add to plan" onClick={() => togglePlanned(site.id)}>
              <window.Icon name="bookmark" size={14} />
            </button>
            <button className={window.cx("btn-icn", "btn-icn--sm", data.visited && "is-on-terrain")} title="Mark visited" onClick={() => toggleVisited(site.id)}>
              <window.Icon name="checkCircle" size={14} />
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

Object.assign(window, { Nav, SiteCard });
