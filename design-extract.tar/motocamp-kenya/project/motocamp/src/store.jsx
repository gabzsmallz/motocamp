// ============================================================
// KenyaMotocamp — app state: routing + persistent store
// ============================================================
const { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } = React;

const LS_KEY = "kmc_field_v1";
function loadLS() { try { return JSON.parse(localStorage.getItem(LS_KEY)) || {}; } catch { return {}; } }
function saveLS(s) { try { localStorage.setItem(LS_KEY, JSON.stringify(s)); } catch {} }

const AppCtx = createContext(null);
const useApp = () => useContext(AppCtx);

function AppProvider({ children }) {
  // ---- persistent slices ----
  const init = loadLS();
  const [siteData, setSiteData] = useState(init.siteData || {});      // {id:{visited,planned,rating,notes,visitedDate}}
  const [userReviews, setUserReviews] = useState(init.userReviews || {}); // {id:[review,...]}
  const [helpful, setHelpful] = useState(init.helpful || {});          // {reviewId:true}
  const [suggestions, setSuggestions] = useState(
    init.suggestions || window.SUGGESTIONS_SEED.map((s) => ({ ...s }))
  );
  const [signedIn, setSignedIn] = useState(init.signedIn ?? true);
  const [isAdmin, setIsAdmin] = useState(init.isAdmin ?? true);

  // ---- routing ----
  function parseHash() {
    const h = (location.hash || "#/").replace(/^#\/?/, "");
    const [screen = "home", id, tab] = h.split("/");
    return { screen: screen || "home", id: id ? decodeURIComponent(id) : null, tab: tab || null };
  }
  const [route, setRoute] = useState(parseHash());
  useEffect(() => {
    const on = () => setRoute(parseHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const go = useCallback((screen, id, tab) => {
    let h = "#/" + screen;
    if (id != null) h += "/" + encodeURIComponent(id);
    if (tab) h += "/" + tab;
    if (location.hash === h) setRoute(parseHash());
    else location.hash = h;
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, []);

  // ---- persist ----
  useEffect(() => { saveLS({ siteData, userReviews, helpful, suggestions, signedIn, isAdmin }); },
    [siteData, userReviews, helpful, suggestions, signedIn, isAdmin]);

  // ---- derived campsites (merge user reviews) ----
  const campsites = useMemo(() => window.CAMPSITES.map((s) => {
    const extra = userReviews[s.id] || [];
    if (!extra.length) return s;
    const all = [...extra, ...s.reviews];
    const agg = { road: 0, facilities: 0, scenery: 0, safety: 0 };
    all.forEach((r) => { agg.road += r.dims.road; agg.facilities += r.dims.facilities; agg.scenery += r.dims.scenery; agg.safety += r.dims.safety; });
    const n = all.length;
    return { ...s, reviews: all, community: {
      count: n, road: agg.road / n, facilities: agg.facilities / n, scenery: agg.scenery / n, safety: agg.safety / n,
      overall: (agg.road + agg.facilities + agg.scenery + agg.safety) / (4 * n),
    } };
  }), [userReviews]);

  const getSite = useCallback((id) => campsites.find((s) => String(s.id) === String(id)), [campsites]);
  const getData = useCallback((id) => siteData[id] || { visited: false, planned: false, rating: 0, notes: "" }, [siteData]);

  // ---- mutations ----
  const patchData = (id, patch) => setSiteData((d) => ({ ...d, [id]: { ...getData(id), ...patch } }));
  const toggleVisited = (id) => { const cur = getData(id); patchData(id, { visited: !cur.visited, visitedDate: !cur.visited ? new Date().toISOString().slice(0, 10) : null, planned: !cur.visited ? false : cur.planned }); };
  const togglePlanned = (id) => { const cur = getData(id); patchData(id, { planned: !cur.planned }); };
  const setRating = (id, r) => patchData(id, { rating: r });
  const setNotes = (id, n) => patchData(id, { notes: n });

  const addReview = (id, review) => {
    const r = { id: `u-${id}-${Date.now()}`, rider: "You", bike: review.bike || "My bike", date: new Date().toISOString().slice(0, 10), helpful: 0, mine: true, ...review };
    setUserReviews((u) => ({ ...u, [id]: [r, ...(u[id] || [])] }));
    if (review.overall) setRating(id, Math.round(review.overall));
  };
  const toggleHelpful = (rid) => setHelpful((h) => ({ ...h, [rid]: !h[rid] }));

  const approveSuggestion = (sgId) => setSuggestions((s) => s.filter((x) => x.id !== sgId));
  const rejectSuggestion = (sgId) => setSuggestions((s) => s.filter((x) => x.id !== sgId));

  const stats = useMemo(() => {
    const ids = Object.keys(siteData);
    return {
      visited: ids.filter((k) => siteData[k].visited).length,
      planned: ids.filter((k) => siteData[k].planned).length,
    };
  }, [siteData]);

  const value = {
    route, go,
    campsites, getSite, getData,
    siteData, toggleVisited, togglePlanned, setRating, setNotes,
    userReviews, addReview, helpful, toggleHelpful,
    suggestions, approveSuggestion, rejectSuggestion,
    signedIn, setSignedIn, isAdmin, setIsAdmin,
    stats,
  };
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

Object.assign(window, { AppProvider, useApp });
