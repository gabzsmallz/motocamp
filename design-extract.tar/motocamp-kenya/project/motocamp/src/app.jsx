// ============================================================
// KenyaMotocamp — root app + router
// ============================================================
function Placeholder({ title }) {
  return (
    <div className="wrap section" style={{ minHeight: "60vh" }}>
      <span className="eyebrow">Coming up</span>
      <h2 className="display" style={{ fontSize: 30, marginTop: 8 }}>{title}</h2>
      <p className="muted">This screen is being built.</p>
    </div>
  );
}

function App() {
  const { route } = window.useApp();
  let view;
  switch (route.screen) {
    case "home": view = <window.Home />; break;
    case "explore": view = window.Explore ? <window.Explore /> : <Placeholder title="Map" />; break;
    case "site": view = window.SiteDetail ? <window.SiteDetail id={route.id} /> : <Placeholder title="Site detail" />; break;
    case "browse": view = window.Browse ? <window.Browse /> : <Placeholder title="Campsites" />; break;
    case "trips": view = window.Trips ? <window.Trips /> : <Placeholder title="My Trips" />; break;
    case "suggest": view = window.Suggest ? <window.Suggest /> : <Placeholder title="Suggest a site" />; break;
    case "admin": view = window.Admin ? <window.Admin /> : <Placeholder title="Admin" />; break;
    default: view = <window.Home />;
  }
  return (
    <>
      <window.Nav />
      <main>{view}</main>
    </>
  );
}

function Root() {
  return (
    <window.AppProvider>
      <App />
    </window.AppProvider>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Root />);
