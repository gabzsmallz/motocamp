// ============================================================
// KenyaMotocamp — Explore (OpenTopoMap + synced list)
// ============================================================
function downloadGpx(sites, filename) {
  const wpts = sites.map((s) =>
    `  <wpt lat="${s.lat}" lon="${s.lng}">\n    <name>${s.name.replace(/&/g, "&amp;")}</name>\n    <desc>${s.region}, ${s.county} — ${window.ACCESS_LABELS[s.access].label}</desc>\n    <ele>${s.elev}</ele>\n  </wpt>`
  ).join("\n");
  const gpx = `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="KenyaMotocamp" xmlns="http://www.topografix.com/GPX/1/1">\n  <metadata><name>KenyaMotocamp export</name></metadata>\n${wpts}\n</gpx>`;
  const blob = new Blob([gpx], { type: "application/gpx+xml" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

const ACCESS_HEX = { good: "#4c6a3c", moderate: "#b27a14", rough: "#a8341c" };
const STATUS_HEX = { visited: "#4c6a3c", planned: "#b27a14" };

function markerHTML(n, color, active) {
  return `<span class="lf-pin${active ? " is-active" : ""}" style="--pc:${color}"><span class="lf-pin__n">${n}</span></span>`;
}

function Explore() {
  const { campsites, getData, go, toggleVisited, togglePlanned } = window.useApp();
  const [filter, setFilter] = React.useState("all");
  const [search, setSearch] = React.useState("");
  const [hoverId, setHoverId] = React.useState(null);
  const [colorBy, setColorBy] = React.useState("access"); // access | status
  const mapRef = React.useRef(null);
  const mapEl = React.useRef(null);
  const markers = React.useRef({});
  const listRef = React.useRef(null);

  const filtered = React.useMemo(() => campsites.filter((s) => {
    const d = getData(s.id);
    const mS = !search || (s.name + s.region + s.county + s.tags.join(" ")).toLowerCase().includes(search.toLowerCase());
    const mF = filter === "all" ? true : filter === "visited" ? d.visited : filter === "planned" ? d.planned : filter === "unvisited" ? !d.visited && !d.planned : true;
    return mS && mF;
  }), [campsites, search, filter, getData]);

  // init map once
  React.useEffect(() => {
    if (mapRef.current || !mapEl.current || !window.L) return;
    const map = window.L.map(mapEl.current, { center: [0.6, 37.6], zoom: 6, zoomControl: false, attributionControl: false });
    window.L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}", {
      maxZoom: 17,
    }).addTo(map);
    window.L.control.zoom({ position: "bottomright" }).addTo(map);
    window.L.control.attribution({ position: "bottomleft", prefix: false })
      .addAttribution('Tiles © Esri — World Topo').addTo(map);
    mapRef.current = map;
    setTimeout(() => map.invalidateSize(), 200);
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  // rebuild markers when filtered / color mode changes
  React.useEffect(() => {
    const map = mapRef.current; if (!map || !window.L) return;
    Object.values(markers.current).forEach((m) => m.remove());
    markers.current = {};
    filtered.forEach((s, i) => {
      const d = getData(s.id);
      const color = colorBy === "status"
        ? (d.visited ? STATUS_HEX.visited : d.planned ? STATUS_HEX.planned : "#9a8e76")
        : ACCESS_HEX[s.access];
      const icon = window.L.divIcon({ html: markerHTML(s.id, color, false), className: "lf-divicon", iconSize: [30, 30], iconAnchor: [15, 30], popupAnchor: [0, -28] });
      const m = window.L.marker([s.lat, s.lng], { icon }).addTo(map);
      const access = window.ACCESS_LABELS[s.access];
      m.bindPopup(
        `<div class="lf-pop">
           <div class="lf-pop__name">${s.name}</div>
           <div class="lf-pop__loc">${s.region}, ${s.county}</div>
           <div class="lf-pop__row"><span class="lf-pop__chip" style="--c:${ACCESS_HEX[s.access]}">${access.label}</span><span class="lf-pop__score">★ ${window.round1(s.community.overall).toFixed(1)}</span></div>
           <div class="lf-pop__meta">${s.fee} · ${s.distanceFromNairobi} km from Nairobi</div>
           <button class="lf-pop__btn" data-go="${s.id}">View field report →</button>
         </div>`, { className: "lf-pop-wrap", maxWidth: 240 });
      m.on("mouseover", () => setHoverId(s.id));
      m.on("mouseout", () => setHoverId(null));
      m.on("popupopen", (e) => {
        const btn = e.popup.getElement().querySelector("[data-go]");
        if (btn) btn.onclick = () => go("site", s.id);
      });
      markers.current[s.id] = m;
    });
  }, [filtered, colorBy, getData]);

  // reflect hover onto markers
  React.useEffect(() => {
    Object.entries(markers.current).forEach(([id, m]) => {
      const el = m.getElement()?.querySelector(".lf-pin");
      if (el) el.classList.toggle("is-active", String(id) === String(hoverId));
      if (String(id) === String(hoverId)) m.setZIndexOffset(1000); else m.setZIndexOffset(0);
    });
  }, [hoverId]);

  function flyTo(s) { mapRef.current?.flyTo([s.lat, s.lng], 11, { duration: 1.1 }); }

  return (
    <div className="explore">
      {/* LEFT PANEL */}
      <aside className="explore__panel">
        <div className="explore__panel-head">
          <div className="row gap-2" style={{ justifyContent: "space-between" }}>
            <span className="eyebrow">Sheet 1 · {filtered.length} of {campsites.length} sites</span>
            <button className="explore__gpx" disabled={!filtered.length}
              onClick={() => downloadGpx(filtered, `motocamp-${filter}.gpx`)} title="Export visible sites as GPX">
              <window.Icon name="download" size={13} /> GPX
            </button>
          </div>
          <div className="explore__search">
            <window.Icon name="search" size={16} className="explore__search-icn" />
            <input className="explore__search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter sites…" />
            {search && <button className="explore__search-x" onClick={() => setSearch("")}><window.Icon name="x" size={14} /></button>}
          </div>
          <div className="explore__filters scry">
            {[["all", "All"], ["planned", "Planned"], ["visited", "Visited"], ["unvisited", "Not yet"]].map(([k, l]) => (
              <button key={k} className={window.cx("chip", filter === k && "is-on")} onClick={() => setFilter(k)}>{l}</button>
            ))}
            <span className="explore__sep" />
            <button className={window.cx("chip", colorBy === "access" && "is-on")} onClick={() => setColorBy("access")} title="Colour pins by road access">By access</button>
            <button className={window.cx("chip", colorBy === "status" && "is-on")} onClick={() => setColorBy("status")} title="Colour pins by your status">By status</button>
          </div>
        </div>

        <div className="explore__list scry" ref={listRef}>
          {filtered.map((s) => {
            const d = getData(s.id);
            const tone = colorBy === "status" ? (d.visited ? "terrain" : d.planned ? "amber" : "signal") : window.ACCESS_LABELS[s.access].token;
            return (
              <div key={s.id} className={window.cx("ex-item", String(s.id) === String(hoverId) && "is-hover")}
                onMouseEnter={() => setHoverId(s.id)} onMouseLeave={() => setHoverId(null)}
                onClick={() => { flyTo(s); }}>
                <div className="ex-item__pin"><window.WaypointPin n={s.id} tone={tone} size={26} active={String(s.id) === String(hoverId)} /></div>
                <window.SiteImg src={s.photos?.[0]} alt={s.name} className="ex-item__img" />
                <div className="ex-item__body">
                  <div className="ex-item__name">{s.name}</div>
                  <div className="ex-item__loc">{s.region}, {s.county}</div>
                  <div className="ex-item__meta">
                    <window.AccessChip access={s.access} />
                    <span className="ex-item__score">★ {window.round1(s.community.overall).toFixed(1)}</span>
                  </div>
                  <div className="coord ex-item__coord">{s.distanceFromNairobi} km · {s.fee}</div>
                </div>
                <button className="ex-item__open" onClick={(e) => { e.stopPropagation(); go("site", s.id); }} title="Open field report">
                  <window.Icon name="chevronRight" size={16} />
                </button>
              </div>
            );
          })}
          {!filtered.length && <div className="ex-empty">No sites match.<br />Try clearing filters.</div>}
        </div>
      </aside>

      {/* MAP */}
      <div className="explore__map-wrap">
        <div ref={mapEl} className="explore__map" />
        <div className="explore__legend">
          <div className="explore__legend-title font-mono">LEGEND · {colorBy === "access" ? "ROAD ACCESS" : "MY STATUS"}</div>
          {colorBy === "access"
            ? [["good", "Good road"], ["moderate", "Moderate"], ["rough", "Rough / ADV"]].map(([k, l]) => (
                <div key={k} className="explore__legend-row"><span className="explore__legend-dot" style={{ background: ACCESS_HEX[k] }} />{l}</div>))
            : [["visited", "Visited"], ["planned", "Planned"], ["none", "Not yet"]].map(([k, l]) => (
                <div key={k} className="explore__legend-row"><span className="explore__legend-dot" style={{ background: STATUS_HEX[k] || "#9a8e76" }} />{l}</div>))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Explore });
