// ============================================================
// KenyaMotocamp — Suggest a campsite
// ============================================================
function Suggest() {
  const { go } = window.useApp();
  const [f, setF] = React.useState({ name: "", region: "", county: "", lat: "", lng: "", access: "moderate", fee: "", description: "", source: "", facilities: [] });
  const [done, setDone] = React.useState(false);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const toggleFac = (k) => setF((s) => ({ ...s, facilities: s.facilities.includes(k) ? s.facilities.filter((x) => x !== k) : [...s.facilities, k] }));
  const ready = f.name.trim() && f.county.trim() && f.description.trim().length > 12;

  function submit(e) {
    e.preventDefault();
    if (!ready) return;
    setDone(true);
  }

  if (done) return (
    <div className="wrap section suggest__done-wrap">
      <div className="suggest__done card">
        <window.TickCorners inset={11} len={15} />
        <span className="suggest__done-seal"><window.Icon name="check" size={30} /></span>
        <h1 className="display" style={{ fontSize: 30 }}>Submitted for review</h1>
        <p className="muted" style={{ maxWidth: 420 }}>
          Thanks for the intel. <b>{f.name}</b> is now in the moderation queue — an editor will verify the
          coordinates and conditions before it goes live on the map.
        </p>
        <div className="row gap-3">
          <button className="btn btn--signal" onClick={() => go("browse")}>Browse campsites</button>
          <button className="btn" onClick={() => { setDone(false); setF({ name: "", region: "", county: "", lat: "", lng: "", access: "moderate", fee: "", description: "", source: "", facilities: [] }); }}>Suggest another</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="suggest">
      <div className="browse__band">
        <window.ContourBg seeds={[[0.25, 0.5, 7], [0.8, 0.4, 6]]} color="var(--line)" opacity={0.6} />
        <div className="wrap browse__band-inner">
          <div>
            <span className="eyebrow">Help the map grow</span>
            <h1 className="browse__title display">Suggest a campsite</h1>
          </div>
        </div>
      </div>

      <div className="wrap browse__body">
        <form className="suggest__form" onSubmit={submit}>
          <div className="suggest__cols">
            <div className="suggest__col">
              <div className="suggest__field">
                <label className="field-label">Campsite name *</label>
                <input className="input" value={f.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Marich Pass River Camp" />
              </div>
              <div className="suggest__row2">
                <div className="suggest__field"><label className="field-label">Region</label><input className="input" value={f.region} onChange={(e) => set("region", e.target.value)} placeholder="Marich Pass" /></div>
                <div className="suggest__field"><label className="field-label">County *</label><input className="input" value={f.county} onChange={(e) => set("county", e.target.value)} placeholder="West Pokot" /></div>
              </div>
              <div className="suggest__row2">
                <div className="suggest__field"><label className="field-label">Latitude</label><input className="input font-mono" value={f.lat} onChange={(e) => set("lat", e.target.value)} placeholder="1.5500" /></div>
                <div className="suggest__field"><label className="field-label">Longitude</label><input className="input font-mono" value={f.lng} onChange={(e) => set("lng", e.target.value)} placeholder="35.4500" /></div>
              </div>
              <div className="suggest__field">
                <label className="field-label">Field notes / description *</label>
                <textarea className="textarea" rows={5} value={f.description} onChange={(e) => set("description", e.target.value)} placeholder="What's the approach like? Facilities? Why should riders go?" />
              </div>
            </div>

            <div className="suggest__col">
              <div className="suggest__field">
                <label className="field-label">Road access</label>
                <div className="suggest__access">
                  {["good", "moderate", "rough"].map((k) => (
                    <button type="button" key={k} className={window.cx("suggest__access-btn", `tone-${window.ACCESS_LABELS[k].token}`, f.access === k && "is-on")} onClick={() => set("access", k)}>
                      <span className="access-chip__dot" />{window.ACCESS_LABELS[k].label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="suggest__field">
                <label className="field-label">Camp fee</label>
                <input className="input" value={f.fee} onChange={(e) => set("fee", e.target.value)} placeholder="KES 800 + park fees" />
              </div>
              <div className="suggest__field">
                <label className="field-label">Facilities</label>
                <div className="suggest__facs">
                  {Object.keys(window.FACILITY_ICONS).map((k) => (
                    <button type="button" key={k} className={window.cx("suggest__fac", f.facilities.includes(k) && "is-on")} onClick={() => toggleFac(k)}>
                      {window.FACILITY_ICONS[k].label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="suggest__field">
                <label className="field-label">Source (optional)</label>
                <input className="input" value={f.source} onChange={(e) => set("source", e.target.value)} placeholder="YouTube channel or your name" />
              </div>
              <div className="suggest__note coord">
                Submissions enter a moderation queue. An editor verifies coordinates &amp; conditions before publishing.
              </div>
            </div>
          </div>
          <div className="suggest__submit">
            <button className="btn btn--signal" disabled={!ready}><window.Icon name="plus" size={16} /> Submit for review</button>
            {!ready && <span className="coord">Name, county &amp; a description are required.</span>}
          </div>
        </form>
      </div>
    </div>
  );
}

Object.assign(window, { Suggest });
