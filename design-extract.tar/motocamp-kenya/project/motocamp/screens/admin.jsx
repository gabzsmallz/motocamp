// ============================================================
// KenyaMotocamp — Admin (moderation, photos, stats, directory)
// ============================================================
function Admin() {
  const { campsites, suggestions, approveSuggestion, rejectSuggestion, isAdmin, go } = window.useApp();
  const [tab, setTab] = React.useState("queue");

  React.useEffect(() => { if (!isAdmin) go("home"); }, [isAdmin]);
  if (!isAdmin) return null;

  const tabs = [
    { k: "queue", label: "Moderation", count: suggestions.length },
    { k: "photos", label: "Photos" },
    { k: "stats", label: "Stats" },
    { k: "directory", label: "Directory" },
  ];

  return (
    <div className="admin">
      <div className="admin__band">
        <div className="wrap admin__band-inner">
          <span className="admin__shield"><window.Icon name="shield" size={20} /></span>
          <div>
            <h1 className="admin__title display">Editor console</h1>
            <div className="coord">Signed in as editor@kenyamotocamp.ke · full access</div>
          </div>
          <div className="admin__band-stat">
            <div className="admin__band-stat-v font-mono">{suggestions.length}</div>
            <div className="admin__band-stat-l">pending</div>
          </div>
        </div>
      </div>

      <div className="wrap admin__body">
        <div className="admin__tabs">
          {tabs.map((t) => (
            <button key={t.k} className={window.cx("admin__tab", tab === t.k && "is-on")} onClick={() => setTab(t.k)}>
              {t.label}
              {t.count > 0 && <span className="admin__tab-badge">{t.count}</span>}
            </button>
          ))}
        </div>

        {tab === "queue" && <QueueTab suggestions={suggestions} approve={approveSuggestion} reject={rejectSuggestion} />}
        {tab === "photos" && <PhotosTab campsites={campsites} />}
        {tab === "stats" && <StatsTab campsites={campsites} suggestions={suggestions} />}
        {tab === "directory" && <DirectoryTab campsites={campsites} go={go} />}
      </div>
    </div>
  );
}

function QueueTab({ suggestions, approve, reject }) {
  const [acted, setActed] = React.useState({});
  function doAct(id, kind) {
    setActed((a) => ({ ...a, [id]: kind }));
    setTimeout(() => { kind === "approve" ? approve(id) : reject(id); }, 420);
  }
  if (!suggestions.length) return (
    <div className="admin__empty card">
      <window.TickCorners inset={10} len={14} />
      <window.Icon name="checkCircle" size={34} />
      <div className="display" style={{ fontSize: 21 }}>Queue clear</div>
      <p className="muted" style={{ margin: 0 }}>No campsites waiting for review. Nicely done.</p>
    </div>
  );
  return (
    <div>
      <p className="admin__lead">Review rider-submitted campsites. Approving publishes them to the live map; rejecting discards the submission.</p>
      <div className="admin__queue">
        {suggestions.map((s) => (
          <article key={s.id} className={window.cx("subm card", acted[s.id] && `is-${acted[s.id]}`)}>
            <div className="subm__inner">
              <div className="subm__head">
                <div>
                  <h3 className="subm__name">{s.name}</h3>
                  <div className="subm__loc"><window.Icon name="pin" size={12} /> {s.region && `${s.region}, `}{s.county} · submitted {s.submittedAgo}</div>
                </div>
                <window.AccessChip access={s.access} />
              </div>
              <p className="subm__desc">{s.description}</p>
              <div className="subm__meta">
                {s.lat && <span className="coord"><window.Icon name="pin" size={11} /> {s.lat}, {s.lng}</span>}
                {s.fee && <span className="coord">{s.fee}</span>}
                {s.facilities?.length > 0 && <span className="coord">{s.facilities.length} facilities</span>}
                {s.source && <span className="coord">▶ {s.source}</span>}
                <span className="coord subm__by">{s.submittedBy}</span>
              </div>
              <div className="subm__actions">
                <button className="btn btn--signal btn--sm" onClick={() => doAct(s.id, "approve")}><window.Icon name="check" size={15} /> Approve &amp; publish</button>
                <button className="btn btn--sm" onClick={() => doAct(s.id, "reject")}><window.Icon name="x" size={15} /> Reject</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function PhotosTab({ campsites }) {
  const [siteId, setSiteId] = React.useState("");
  const [extra, setExtra] = React.useState({}); // {id:[urls]}
  const [removed, setRemoved] = React.useState({}); // {id:[urls]}
  const [url, setUrl] = React.useState("");
  const [msg, setMsg] = React.useState("");
  const site = campsites.find((s) => String(s.id) === String(siteId));
  const photos = site ? [...(site.photos || []).filter((p) => !(removed[siteId] || []).includes(p)), ...(extra[siteId] || [])] : [];

  function add() {
    if (!url.trim() || !site) return;
    setExtra((e) => ({ ...e, [siteId]: [...(e[siteId] || []), url.trim()] }));
    setUrl(""); setMsg("Photo added — live on map & cards."); setTimeout(() => setMsg(""), 2500);
  }
  function remove(p) { setRemoved((r) => ({ ...r, [siteId]: [...(r[siteId] || []), p] })); setExtra((e) => ({ ...e, [siteId]: (e[siteId] || []).filter((x) => x !== p) })); }

  return (
    <div>
      <p className="admin__lead">Manage photos for any campsite. Paste a URL (or upload) — changes appear live on the map and list. The first photo is the cover.</p>
      <div className="photos__select">
        <label className="field-label">Select campsite</label>
        <select className="select" value={siteId} onChange={(e) => { setSiteId(e.target.value); setMsg(""); }} style={{ maxWidth: 420 }}>
          <option value="">— Choose a campsite —</option>
          {campsites.map((s) => <option key={s.id} value={s.id}>{s.name} ({(s.photos || []).length} photos)</option>)}
        </select>
      </div>

      {site && (
        <div className="photos__panel card">
          <div className="photos__panel-inner">
            <h3 className="photos__h"><window.Icon name="image" size={16} /> {site.name}</h3>
            <div className="photos__add">
              <div className="photos__add-url">
                <label className="field-label"><window.Icon name="link" size={11} /> Paste photo URL</label>
                <div className="row gap-2">
                  <input className="input" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="https://images.unsplash.com/…" />
                  <button className="btn btn--signal" type="button" onClick={add} disabled={!url.trim()}>Add</button>
                </div>
              </div>
              <div className="photos__add-up">
                <label className="field-label"><window.Icon name="upload" size={11} /> Or upload</label>
                <button className="btn" type="button" onClick={() => { setMsg("In the live app this opens the device picker & uploads to storage."); setTimeout(() => setMsg(""), 3000); }}>
                  <window.Icon name="upload" size={15} /> Choose image
                </button>
              </div>
            </div>
            {msg && <div className="photos__msg coord"><window.Icon name="check" size={12} /> {msg}</div>}
            <div className="photos__grid">
              {photos.map((p, i) => (
                <div key={p + i} className="photos__cell">
                  <img src={p} alt="" loading="lazy" />
                  <button className="photos__cell-del" onClick={() => remove(p)} title="Remove"><window.Icon name="trash" size={13} /></button>
                  {i === 0 && <span className="photos__cell-cover">Cover</span>}
                </div>
              ))}
              {!photos.length && <div className="photos__none coord">No photos yet for this campsite.</div>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatsTab({ campsites, suggestions }) {
  const totalReports = campsites.reduce((a, s) => a + s.community.count, 0);
  const avg = campsites.reduce((a, s) => a + s.community.overall, 0) / campsites.length;
  const counties = [...new Set(campsites.map((s) => s.county))].map((c) => ({ c, n: campsites.filter((s) => s.county === c).length })).sort((a, b) => b.n - a.n);
  const maxC = Math.max(...counties.map((c) => c.n));
  const access = ["good", "moderate", "rough"].map((k) => ({ k, ...window.ACCESS_LABELS[k], n: campsites.filter((s) => s.access === k).length }));

  return (
    <div className="stats">
      <div className="stats__cards">
        {[
          { l: "Campsites live", v: campsites.length, icon: "tent" },
          { l: "Field reports", v: totalReports, icon: "users" },
          { l: "Avg score", v: avg.toFixed(1), icon: "star" },
          { l: "Pending review", v: suggestions.length, icon: "clock" },
        ].map((s) => (
          <div key={s.l} className="stats__card card">
            <window.Icon name={s.icon} size={20} className="stats__card-icn" />
            <div className="stats__card-v font-mono">{s.v}</div>
            <div className="stats__card-l">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="stats__cols">
        <div className="stats__panel card">
          <div className="stats__panel-inner">
            <h3 className="stats__h">Coverage by county</h3>
            <div className="stats__bars">
              {counties.map((c) => (
                <div key={c.c} className="stats__bar-row">
                  <span className="stats__bar-l">{c.c}</span>
                  <div className="stats__bar-track"><div className="stats__bar-fill" style={{ width: `${(c.n / maxC) * 100}%` }} /></div>
                  <span className="coord">{c.n}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="stats__panel card">
          <div className="stats__panel-inner">
            <h3 className="stats__h">Terrain distribution</h3>
            <div className="stats__donut-wrap">
              <div className="stats__access">
                {access.map((a) => (
                  <div key={a.k} className="stats__access-row">
                    <span className={window.cx("stats__access-dot", `bg-${a.token}`)} />
                    <span className="stats__access-l">{a.label}</span>
                    <div className="stats__bar-track"><div className={window.cx("stats__bar-fill", `bg-${a.token}`)} style={{ width: `${(a.n / campsites.length) * 100}%` }} /></div>
                    <span className="coord">{a.n}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DirectoryTab({ campsites, go }) {
  return (
    <div>
      <p className="admin__lead">All {campsites.length} campsites on file. Click any row to open its public field report.</p>
      <div className="dir card">
        <div className="dir__head">
          <span>#</span><span>Campsite</span><span>County</span><span>Access</span><span>Reports</span><span>Score</span>
        </div>
        {campsites.map((s) => (
          <div key={s.id} className="dir__row" onClick={() => go("site", s.id)}>
            <span className="coord">{String(s.id).padStart(2, "0")}</span>
            <span className="dir__name">{s.name}</span>
            <span className="dir__county">{s.county}</span>
            <span><window.AccessChip access={s.access} /></span>
            <span className="coord">{s.community.count}</span>
            <span className="dir__score">★ {window.round1(s.community.overall).toFixed(1)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Admin });
