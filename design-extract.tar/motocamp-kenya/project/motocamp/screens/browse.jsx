// ============================================================
// KenyaMotocamp — Browse (list + filters)
// ============================================================
function Browse() {
  const { campsites, getData, go } = window.useApp();
  const [search, setSearch] = React.useState(window.__pendingSearch || "");
  const [access, setAccess] = React.useState(window.__pendingAccess || "all");
  const [status, setStatus] = React.useState("all");
  const [county, setCounty] = React.useState("all");
  const [fac, setFac] = React.useState("all");
  const [sort, setSort] = React.useState("rating");
  const [view, setView] = React.useState("grid");

  React.useEffect(() => { window.__pendingSearch = ""; window.__pendingAccess = ""; }, []);

  const counties = React.useMemo(() => [...new Set(campsites.map((s) => s.county))].sort(), [campsites]);

  const filtered = React.useMemo(() => {
    let arr = campsites.filter((s) => {
      const d = getData(s.id);
      const mS = !search || (s.name + s.region + s.county + s.tags.join(" ") + s.description).toLowerCase().includes(search.toLowerCase());
      const mA = access === "all" || s.access === access;
      const mC = county === "all" || s.county === county;
      const mFa = fac === "all" || s.facilities.includes(fac);
      const mSt = status === "all" ? true : status === "visited" ? d.visited : status === "planned" ? d.planned : status === "unvisited" ? !d.visited && !d.planned : true;
      return mS && mA && mC && mFa && mSt;
    });
    arr = [...arr].sort((a, b) =>
      sort === "rating" ? b.community.overall - a.community.overall :
      sort === "name" ? a.name.localeCompare(b.name) :
      sort === "distance" ? a.distanceFromNairobi - b.distanceFromNairobi :
      sort === "elev" ? b.elev - a.elev : 0);
    return arr;
  }, [campsites, search, access, county, fac, status, sort, getData]);

  const vis = campsites.filter((s) => getData(s.id).visited).length;
  const pln = campsites.filter((s) => getData(s.id).planned).length;
  const activeFilters = [access !== "all", status !== "all", county !== "all", fac !== "all"].filter(Boolean).length;

  function reset() { setSearch(""); setAccess("all"); setStatus("all"); setCounty("all"); setFac("all"); }

  return (
    <div className="browse">
      {/* header band */}
      <div className="browse__band">
        <window.ContourBg seeds={[[0.2, 0.5, 6], [0.8, 0.4, 7]]} color="var(--line)" opacity={0.6} />
        <div className="wrap browse__band-inner">
          <div>
            <span className="eyebrow">Directory · {campsites.length} sites on file</span>
            <h1 className="browse__title display">All campsites</h1>
          </div>
          <div className="browse__counts">
            {[["Total", campsites.length, "ink"], ["Visited", vis, "terrain"], ["Planned", pln, "amber"], ["Remaining", campsites.length - vis, "signal"]].map(([l, v, t]) => (
              <div key={l} className={window.cx("browse__count", `tone-${t}`)}>
                <div className="browse__count-v font-mono">{String(v).padStart(2, "0")}</div>
                <div className="browse__count-l">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="wrap browse__body">
        {/* controls */}
        <div className="browse__controls">
          <div className="browse__search">
            <window.Icon name="search" size={17} className="browse__search-icn" />
            <input className="browse__search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search campsites, regions, terrain, tags…" />
            {search && <button className="explore__search-x" onClick={() => setSearch("")}><window.Icon name="x" size={14} /></button>}
          </div>
          <div className="browse__view">
            <button className={window.cx("browse__view-btn", view === "grid" && "is-on")} onClick={() => setView("grid")} title="Grid"><window.Icon name="layers" size={16} /></button>
            <button className={window.cx("browse__view-btn", view === "list" && "is-on")} onClick={() => setView("list")} title="List"><window.Icon name="list" size={16} /></button>
          </div>
        </div>

        <div className="browse__filterbar">
          <Selector label="Status" value={status} onChange={setStatus} options={[["all", "All"], ["visited", "Visited"], ["planned", "Planned"], ["unvisited", "Not yet"]]} />
          <Selector label="Access" value={access} onChange={setAccess} options={[["all", "All"], ["good", "Good road"], ["moderate", "Moderate"], ["rough", "Rough / ADV"]]} />
          <Selector label="County" value={county} onChange={setCounty} options={[["all", "All"], ...counties.map((c) => [c, c])]} />
          <Selector label="Facility" value={fac} onChange={setFac} options={[["all", "Any"], ["water", "Water"], ["showers", "Showers"], ["toilets", "Toilets"], ["restaurant", "Food"], ["campfire", "Campfire"]]} />
          <Selector label="Sort" value={sort} onChange={setSort} options={[["rating", "Top rated"], ["distance", "Nearest Nairobi"], ["elev", "Highest"], ["name", "A–Z"]]} />
          <div className="browse__filter-meta">
            <span className="coord">{filtered.length} result{filtered.length !== 1 ? "s" : ""}</span>
            {(activeFilters > 0 || search) && <button className="browse__reset" onClick={reset}><window.Icon name="x" size={12} /> Clear</button>}
          </div>
        </div>

        {/* results */}
        {filtered.length ? (
          view === "grid" ? (
            <div className="card-grid card-grid--3 browse__grid">
              {filtered.map((s) => <window.SiteCard key={s.id} site={s} n={s.id} />)}
            </div>
          ) : (
            <div className="browse__list">
              {filtered.map((s) => <BrowseRow key={s.id} site={s} />)}
            </div>
          )
        ) : (
          <div className="browse__empty card">
            <window.Icon name="compass" size={36} />
            <div className="display" style={{ fontSize: 20 }}>No sites match</div>
            <p className="muted" style={{ margin: 0 }}>Try widening your filters.</p>
            <button className="btn" onClick={reset}>Clear all filters</button>
          </div>
        )}
      </div>
    </div>
  );
}

function Selector({ label, value, onChange, options }) {
  return (
    <label className="browse__sel">
      <span className="browse__sel-l font-mono">{label}</span>
      <select className="select browse__sel-input" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </label>
  );
}

function BrowseRow({ site }) {
  const { go, getData, toggleVisited, togglePlanned } = window.useApp();
  const d = getData(site.id);
  const tone = d.visited ? "terrain" : d.planned ? "amber" : window.ACCESS_LABELS[site.access].token;
  return (
    <div className="brow" onClick={() => go("site", site.id)}>
      <div className="brow__pin"><window.WaypointPin n={site.id} tone={tone} size={28} /></div>
      <window.SiteImg src={site.photos?.[0]} alt={site.name} className="brow__img" />
      <div className="brow__body">
        <div className="brow__name">{site.name}</div>
        <div className="brow__loc"><window.Icon name="pin" size={12} /> {site.region}, {site.county}</div>
        <p className="brow__desc">{site.description}</p>
      </div>
      <div className="brow__mid">
        <window.AccessChip access={site.access} />
        <window.Facilities items={site.facilities.slice(0, 4)} />
      </div>
      <div className="brow__stat">
        <div className="brow__score"><window.Icon name="star" size={13} strokeWidth={0} style={{ fill: "var(--signal)" }} /> {window.round1(site.community.overall).toFixed(1)}</div>
        <div className="coord">{site.distanceFromNairobi} km · {site.elev} m</div>
      </div>
      <div className="brow__actions" onClick={(e) => e.stopPropagation()}>
        <button className={window.cx("btn-icn", "btn-icn--sm", d.planned && "is-on-amber")} onClick={() => togglePlanned(site.id)} title="Plan"><window.Icon name="bookmark" size={14} /></button>
        <button className={window.cx("btn-icn", "btn-icn--sm", d.visited && "is-on-terrain")} onClick={() => toggleVisited(site.id)} title="Visited"><window.Icon name="checkCircle" size={14} /></button>
      </div>
    </div>
  );
}

Object.assign(window, { Browse });
