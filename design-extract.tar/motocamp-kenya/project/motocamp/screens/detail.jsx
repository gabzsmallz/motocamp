// ============================================================
// KenyaMotocamp — Site Detail + structured reviews
// ============================================================
function PhotoGallery({ photos, name }) {
  const [active, setActive] = React.useState(0);
  const [err, setErr] = React.useState({});
  const list = photos.filter((_, i) => !err[i]);
  if (!photos.length) return (
    <div className="gallery gallery--empty"><window.Icon name="mountain" size={36} /><span className="coord">No photos logged yet</span></div>
  );
  return (
    <div className="gallery">
      <div className="gallery__main">
        <img src={photos[active]} alt={name} onError={() => setErr((e) => ({ ...e, [active]: true }))} />
        <window.TickCorners inset={10} len={14} color="#fff" opacity={0.7} />
        <span className="gallery__count font-mono">{active + 1} / {photos.length}</span>
      </div>
      {photos.length > 1 && (
        <div className="gallery__thumbs">
          {photos.map((p, i) => (
            <button key={i} className={window.cx("gallery__thumb", i === active && "is-on")} onClick={() => setActive(i)}>
              <img src={p} alt="" onError={() => setErr((e) => ({ ...e, [i]: true }))} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ReviewCard({ r, siteId }) {
  const { helpful, toggleHelpful } = window.useApp();
  const isHelpful = helpful[r.id];
  return (
    <article className={window.cx("review", r.mine && "review--mine")}>
      <div className="review__head">
        <window.Avatar name={r.rider} size={38} />
        <div className="review__who">
          <div className="review__name">{r.rider} {r.mine && <span className="review__you-tag">You</span>}</div>
          <div className="review__bike font-mono"><window.Icon name="compass" size={11} /> {r.bike}</div>
        </div>
        <div className="review__overall">
          <div className="review__overall-n">{window.round1(r.overall).toFixed(1)}</div>
          <div className="review__date font-mono">{r.date}</div>
        </div>
      </div>
      <p className="review__text">{r.text}</p>
      {r.photo && <div className="review__photo"><img src={r.photo} alt="" loading="lazy" /></div>}
      <div className="review__dims">
        {window.RATING_DIMS.map((d) => (
          <div key={d.key} className="review__dim">
            <span className="review__dim-l font-mono">{d.label}</span>
            <div className="review__dim-dots">
              {[1, 2, 3, 4, 5].map((n) => (
                <span key={n} className={window.cx("review__dot", r.dims[d.key] >= n - 0.25 && "is-on")} />
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="review__foot">
        <button className={window.cx("review__helpful", isHelpful && "is-on")} onClick={() => toggleHelpful(r.id)}>
          <window.Icon name="thumbsUp" size={14} /> Helpful{(r.helpful + (isHelpful ? 1 : 0)) > 0 ? ` · ${r.helpful + (isHelpful ? 1 : 0)}` : ""}
        </button>
      </div>
    </article>
  );
}

function ReviewForm({ site }) {
  const { addReview } = window.useApp();
  const [open, setOpen] = React.useState(false);
  const [dims, setDims] = React.useState({ road: 0, facilities: 0, scenery: 0, safety: 0 });
  const [text, setText] = React.useState("");
  const [bike, setBike] = React.useState("");
  const [done, setDone] = React.useState(false);
  const ready = Object.values(dims).every((v) => v > 0) && text.trim().length > 4;

  function submit(e) {
    e.preventDefault();
    if (!ready) return;
    const overall = (dims.road + dims.facilities + dims.scenery + dims.safety) / 4;
    addReview(site.id, { dims: { ...dims }, overall: Math.round(overall * 10) / 10, text: text.trim(), bike: bike.trim() || "My bike", photo: null });
    setDone(true);
    setTimeout(() => { setOpen(false); setDone(false); setDims({ road: 0, facilities: 0, scenery: 0, safety: 0 }); setText(""); setBike(""); }, 1600);
  }

  if (!open) return (
    <button className="btn btn--signal btn--block reviewform__open" onClick={() => setOpen(true)}>
      <window.Icon name="plus" size={16} /> File a field report
    </button>
  );

  return (
    <form className="reviewform card" onSubmit={submit}>
      <window.TickCorners inset={9} len={12} />
      <div className="reviewform__inner">
        {done ? (
          <div className="reviewform__done">
            <span className="reviewform__done-mark"><window.Icon name="check" size={26} /></span>
            <div className="display" style={{ fontSize: 20 }}>Report filed.</div>
            <p className="muted" style={{ fontSize: 13, margin: 0 }}>Your scores now count toward the community average.</p>
          </div>
        ) : (
          <>
            <div className="reviewform__head">
              <span className="eyebrow">New field report</span>
              <button type="button" className="btn-icn btn-icn--sm" onClick={() => setOpen(false)}><window.Icon name="x" size={15} /></button>
            </div>
            <div className="reviewform__dims">
              {window.RATING_DIMS.map((d) => (
                <div key={d.key} className="reviewform__dim">
                  <div className="reviewform__dim-head">
                    <span className="reviewform__dim-l">{d.label}</span>
                    <span className="reviewform__dim-hint">{d.hint}</span>
                  </div>
                  <window.StarInput value={dims[d.key]} onChange={(v) => setDims((s) => ({ ...s, [d.key]: v }))} size={24} />
                </div>
              ))}
            </div>
            <div className="reviewform__field">
              <label className="field-label">Your bike (optional)</label>
              <input className="input" value={bike} onChange={(e) => setBike(e.target.value)} placeholder="e.g. KTM 790 Adventure" />
            </div>
            <div className="reviewform__field">
              <label className="field-label">Trip notes</label>
              <textarea className="textarea" rows={3} value={text} onChange={(e) => setText(e.target.value)} placeholder="How was the approach? Facilities? Anything riders should know before they go?" />
            </div>
            <button className="btn btn--signal btn--block" disabled={!ready}>Publish report</button>
          </>
        )}
      </div>
    </form>
  );
}

function SiteDetail({ id }) {
  const { getSite, getData, toggleVisited, togglePlanned, setNotes, go } = window.useApp();
  const site = getSite(id);
  const [notes, setLocalNotes] = React.useState("");
  const [saved, setSaved] = React.useState(false);
  const [shared, setShared] = React.useState(false);
  const [sortRev, setSortRev] = React.useState("recent");
  const saveT = React.useRef(null);

  React.useEffect(() => { setLocalNotes(getData(id).notes || ""); }, [id]);

  if (!site) return (
    <div className="wrap section" style={{ textAlign: "center", minHeight: "50vh" }}>
      <p className="muted">Campsite not found.</p>
      <button className="btn" onClick={() => go("browse")}>Back to campsites</button>
    </div>
  );

  const data = getData(site.id);
  const access = window.ACCESS_LABELS[site.access];
  const comm = site.community;

  function changeNotes(v) {
    setLocalNotes(v); setSaved(false);
    clearTimeout(saveT.current);
    saveT.current = setTimeout(() => { setNotes(site.id, v); setSaved(true); setTimeout(() => setSaved(false), 1800); }, 700);
  }
  function share() {
    navigator.clipboard?.writeText(`${location.origin}/#/site/${site.id}`).catch(() => {});
    setShared(true); setTimeout(() => setShared(false), 1800);
  }

  const reviews = [...site.reviews].sort((a, b) =>
    sortRev === "recent" ? (a.date < b.date ? 1 : -1) :
    sortRev === "high" ? b.overall - a.overall :
    sortRev === "helpful" ? b.helpful - a.helpful : 0);

  return (
    <div className="detail">
      {/* breadcrumb */}
      <div className="wrap detail__crumb">
        <button onClick={() => go("explore")}><window.Icon name="arrowLeft" size={15} /> Map</button>
        <span className="faint">/</span>
        <button onClick={() => go("browse")}>Campsites</button>
        <span className="faint">/</span>
        <span className="muted">{site.name}</span>
      </div>

      <div className="wrap detail__grid">
        {/* MAIN COLUMN */}
        <div className="detail__main">
          <PhotoGallery photos={site.photos || []} name={site.name} />

          <div className="detail__titleblock">
            <div className="detail__title-row">
              <div>
                <span className="eyebrow">{site.region}</span>
                <h1 className="detail__title display">{site.name}</h1>
                <div className="detail__loc">
                  <window.Icon name="pin" size={14} /> {site.county} County
                  <span className="coord detail__gps">{site.lat.toFixed(4)}°, {site.lng.toFixed(4)}°</span>
                </div>
              </div>
              <window.AccessChip access={site.access} size="lg" />
            </div>

            {/* spec strip */}
            <div className="detail__specs">
              {[
                { l: "Elevation", v: `${site.elev.toLocaleString()} m`, icon: "mountain" },
                { l: "From Nairobi", v: `${site.distanceFromNairobi} km`, icon: "navigation" },
                { l: "Camp fee", v: site.fee, icon: "fuel" },
                { l: "Community", v: `${window.round1(comm.overall).toFixed(1)} / 5`, icon: "star" },
              ].map((s) => (
                <div key={s.l} className="detail__spec">
                  <window.Icon name={s.icon} size={15} className="detail__spec-icn" />
                  <div>
                    <div className="detail__spec-l font-mono">{s.l}</div>
                    <div className="detail__spec-v">{s.v}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* about */}
          <section className="detail__section">
            <h2 className="detail__h2">Field notes</h2>
            <p className="detail__about">{site.description}</p>
            <div className="detail__tags">
              {site.tags.map((t) => <span key={t} className="tag-pill">{t.replace(/_/g, " ")}</span>)}
            </div>
          </section>

          {/* facilities */}
          <section className="detail__section">
            <h2 className="detail__h2">On site</h2>
            <window.Facilities items={site.facilities} className="detail__facs" />
          </section>

          {/* community ratings breakdown */}
          <section className="detail__section detail__ratings">
            <div className="sec-head" style={{ marginBottom: 16 }}>
              <h2 className="detail__h2" style={{ margin: 0 }}>Community scores</h2>
              <span className="coord">{comm.count} field report{comm.count !== 1 ? "s" : ""}</span>
            </div>
            <div className="detail__ratings-grid">
              <div className="detail__overall">
                <window.ScoreBadge value={comm.overall} size="lg" />
                <div className="detail__overall-stars">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <window.Icon key={n} name="star" size={16} strokeWidth={0}
                      style={{ fill: comm.overall >= n - 0.4 ? "var(--signal)" : "var(--line-2)" }} />
                  ))}
                </div>
                <div className="coord">from {comm.count} riders</div>
              </div>
              <div className="detail__dimbars">
                {window.RATING_DIMS.map((d) => (
                  <window.RatingBar key={d.key} label={d.label} value={comm[d.key]} hint={d.hint} />
                ))}
              </div>
            </div>
          </section>

          {/* reviews */}
          <section className="detail__section">
            <div className="sec-head" style={{ marginBottom: 14 }}>
              <h2 className="detail__h2" style={{ margin: 0 }}>Field reports</h2>
              <div className="detail__sort">
                <span className="coord">Sort</span>
                <select className="select select--mini" value={sortRev} onChange={(e) => setSortRev(e.target.value)}>
                  <option value="recent">Most recent</option>
                  <option value="high">Highest rated</option>
                  <option value="helpful">Most helpful</option>
                </select>
              </div>
            </div>
            <div className="detail__reviews">
              {reviews.map((r) => <ReviewCard key={r.id} r={r} siteId={site.id} />)}
            </div>
            <div style={{ marginTop: 16 }}><ReviewForm site={site} /></div>
          </section>
        </div>

        {/* SIDEBAR */}
        <aside className="detail__side">
          <div className="detail__actions card">
            <window.TickCorners inset={9} len={12} />
            <div className="detail__actions-inner">
              <button className={window.cx("btn", "btn--block", data.visited ? "btn--ink" : "")} onClick={() => toggleVisited(site.id)}>
                <window.Icon name="checkCircle" size={16} /> {data.visited ? `Logged · ${data.visitedDate || ""}` : "Mark as visited"}
              </button>
              <button className={window.cx("btn", "btn--block", data.planned ? "btn--signal" : "")} onClick={() => togglePlanned(site.id)}>
                <window.Icon name="bookmark" size={16} /> {data.planned ? "In My Trips" : "Add to My Trips"}
              </button>
              <div className="detail__actions-row">
                <a className="btn" href={`https://www.google.com/maps?q=${site.lat},${site.lng}`} target="_blank" rel="noreferrer">
                  <window.Icon name="navigation" size={15} /> Navigate
                </a>
                <button className={window.cx("btn", shared && "btn--ink")} onClick={share}>
                  <window.Icon name={shared ? "check" : "share"} size={15} /> {shared ? "Copied" : "Share"}
                </button>
              </div>
              <button className="btn btn--ghost btn--block" onClick={() => window.downloadGpx?.([site], `${site.name.replace(/\s+/g, "-")}.gpx`)}>
                <window.Icon name="download" size={15} /> Export waypoint (GPX)
              </button>
            </div>
          </div>

          {/* personal log */}
          <div className="detail__log card">
            <div className="detail__log-inner">
              <div className="sec-head" style={{ marginBottom: 10 }}>
                <span className="eyebrow">My logbook</span>
                {saved && <span className="detail__saved coord"><window.Icon name="check" size={12} /> saved</span>}
              </div>
              <textarea className="textarea detail__notes" rows={5} value={notes} onChange={(e) => changeNotes(e.target.value)}
                placeholder="Private notes — camp spots, where you got fuel, who you rode with…" />
            </div>
          </div>

          {/* featured by */}
          <div className="detail__sources card">
            <div className="detail__sources-inner">
              <span className="eyebrow">Featured by</span>
              <div className="detail__source-list">
                {site.sources.map((src) => (
                  <a key={src} className="detail__source" href={window.SOURCE_LINKS[src] || "#"} target="_blank" rel="noreferrer">
                    <span className="detail__source-play"><window.Icon name="navigation" size={11} /></span>
                    <span>{src}</span>
                    <window.Icon name="externalLink" size={12} className="detail__source-ext" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

Object.assign(window, { SiteDetail });
