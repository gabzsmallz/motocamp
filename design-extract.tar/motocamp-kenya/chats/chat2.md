# Motocamping Site Wording

_Started 2026-06-02 18:21 UTC_

---

## User

The wording pitch might be misleading the site is for motocamping camping grounds. Like the created theme.

## Assistant

_[tool: read_file]_

_[tool: local_ls]_

Let me look at what's already in the project and the attached folder.

_[tool: grep]_

The folder needs re-granting, but let me focus on the actual task. Let me find where "pitch" appears in the site.

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

_[tool: str_replace_edit]_

"Pitch" is actually camping jargon (a pitch = a tent plot), but I get why it reads ambiguously for a motocamping audience — it can sound like a sales pitch or a bike term. I'll swap it for clear camp language while keeping the theme intact. Here are all the spots:

_[tool: str_replace_edit]_

The folder is back, but the wording fix is the priority. One last spot — the campsite name "Loita Hills Forest Pitch". I'll make it "Forest Camp" for consistency:

_[tool: grep]_

All "pitch" references are gone. Let me confirm the site still loads cleanly.

_[tool: done]_

Done. Swapped every "pitch" for clear camp language across the site — theme untouched:

- Hero: "next pitch" → **"next camp"**
- Stat: "ADV-only pitches" → **"ADV-only camps"**
- Plan CTA: "String pitches" → **"String camps"**
- Trips: "{n} pitches" → **"{n} camps"**, "No pitches planned" → **"No camps planned"**
- Detail notes placeholder: "pitch spots" → **"camp spots"**
- A field-note line and the "Loita Hills Forest Pitch" campsite name → **"Forest Camp"**

